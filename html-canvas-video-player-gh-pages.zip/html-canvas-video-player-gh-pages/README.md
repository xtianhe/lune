# HTML canvas video player

### Easy way to play videos inline on iPhones

Simple plain JavaScript class for playing videos on canvas.
IE9+ and modern browsers, but it was intended for iPhone only.

Please let me know if you are using this player, I would like to make a small showcase, thanks!

Thanks to everyone who issued pull requests.

### [Documentation and demo](http://stanko.github.io/html-canvas-video-player).

[![](http://i.imgur.com/kHV1hbh.png)](http://stanko.github.io/html-canvas-video-player)

### Changelog
* Few minor tweaks (thanks to pull requests)
* Added audio support and moved timeline to the main JS file
* Initial release
